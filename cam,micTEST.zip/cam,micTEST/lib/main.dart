import 'package:flutter/material.dart';
import 'package:permission/screens/mic.dart';
// import 'package:permission/screens/camera.dart';
// import 'package:permission/screens/gps.dart';
void main() {
  runApp(const MaterialApp(
    //home: FlutterGPDDemo(),
    //home: FlutterCameraDemo(),
     home: FlutterMicDemo(),
  )
 );
 
 
 }
