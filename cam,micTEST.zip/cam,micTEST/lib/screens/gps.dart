import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class FlutterGPDDemo extends StatefulWidget {
  const FlutterGPDDemo({super.key});

  @override
  State<FlutterGPDDemo> createState() => _FlutterGPDDemoState();
}

class _FlutterGPDDemoState extends State<FlutterGPDDemo> {
  double latitude= 0.0;
  double longitude = 0.0;

  getGPSData() async {
    PermissionStatus gpspermission = await Permission.location.request();
    Position currentPosition = await Geolocator.getCurrentPosition();
setState(() {
  latitude = currentPosition.latitude;
  longitude = currentPosition.longitude;
});
    print(
        "This is the ${currentPosition.latitude} and ${currentPosition.longitude}");
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text("Lat: ${latitude.toString()}"),
            Text("Long: ${longitude.toString()}"),
            OutlinedButton(onPressed: () {
              getGPSData();
            }, child: Text("Get GPD DATA"))
          ],
        ),
      ),
    );
  }
}
