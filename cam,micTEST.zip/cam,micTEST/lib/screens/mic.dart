import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart';

class FlutterMicDemo extends StatefulWidget {
  const FlutterMicDemo({super.key});

  @override
  State<FlutterMicDemo> createState() => _FlutterMicDemoState();
}

class _FlutterMicDemoState extends State<FlutterMicDemo> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initializeMic();
    }

    initializeMic() async{
      PermissionStatus micPermission = await Permission.microphone.request();
      if(micPermission.isGranted){
        await _speech.initialize();
      }
      else if (micPermission.isDenied){
        print("mic is denied");
      }
      else if(micPermission.isPermanentlyDenied){
        print("mic is permanently denied");
        await openAppSettings();

      }
    }
    startMic(){
      _speech.listen(onResult: (listenValue) {
        setState(() {
          micData = listenValue.recognizedWords;
        });
        
      },);

    }
    stopMic(){
  

    }

  String micData ='';
  final SpeechToText _speech = SpeechToText();


  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(body: Center(child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Text("this is the data from MIC: $micData"),
        OutlinedButton(onPressed: (){startMic();}, child: const Text("start listening")),


      ],
    ),),));
  }
}