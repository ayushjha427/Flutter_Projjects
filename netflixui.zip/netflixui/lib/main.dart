import 'package:flutter/material.dart';
// import 'package:flutter_application_2/screen/homepage.dart';
import 'package:netflixui/shared/widget/bottomnav.dart';

void main() {
runApp(const MaterialApp(
//  home: HomePage(),
home: NavBar(),
  ));
}


