import 'package:flutter/material.dart';
import 'package:flutter_application_3/screens/firstpage.dart';

void main(){
 runApp(const MaterialApp(
     home: FirstPage()
 ));
}



