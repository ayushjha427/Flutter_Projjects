import 'package:flutter/material.dart';
import 'package:amazonemusic/screens/homePage.dart';
import 'package:amazonemusic/screens/homePageactual.dart';
import 'package:amazonemusic/screens/loadingScreen.dart';


void main() => runApp(
      MaterialApp(
        theme: ThemeData.dark(),
        // home: LoadingScreen(),
        initialRoute: "/",
        routes: {
          '/': (context) => const LoadingScreen(),
          '/home': (context) => Home(),
          '/home2': (context) => const HomePage2(),
        },
      ),
    );
