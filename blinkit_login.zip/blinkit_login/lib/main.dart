import 'package:loginpage/screen/authscreen.dart';
//import 'package:blinkit/screen/homescreen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: AuthScreen(),));
}

