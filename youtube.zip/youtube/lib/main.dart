import 'package:flutter/material.dart';
import 'package:youtube/pages/dashboard.dart';

void main() {
  runApp(MaterialApp(
home: DashBoard(),
theme: ThemeData.light(),
   

  ));
}

