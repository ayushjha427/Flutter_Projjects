import 'package:flutter/material.dart';
import 'package:youtube/pages/home.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {

 AppBar _buildAppBar(){
  return AppBar(
  actions: const
   [Icon(Icons.search,color: Colors.black,),
  SizedBox(width: 25),
  Icon(Icons.cast,color: Colors.black,),
  SizedBox(width: 25),
  Icon(Icons.notifications,color: Colors.black,),
  SizedBox(width: 20,)],
elevation: 0,
backgroundColor: Colors.transparent,
title: SizedBox(
  
  height: 100,
  child: Image.network('https://cdn.iconscout.com/icon/free/png-256/free-youtube-86-226404.png')));
}
List<BottomNavigationBarItem>  _getItems(){
  return const [
BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home'),
BottomNavigationBarItem(icon: Icon(Icons.subscriptions),label: 'Subscriptions'),
BottomNavigationBarItem(icon: Icon(Icons.library_add),label: 'Library'),

  ];
}
List<Widget> _screens(){

  return[ Home(), const Text('Subscriptions'),const Text('Library')];
}

int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
body: _screens()[index],


appBar: _buildAppBar(),
bottomNavigationBar: BottomNavigationBar(
  onTap: (int currentIndex){
index = currentIndex;
setState(() {

});
  },
  currentIndex: index,items: _getItems()

  ),


 );
  }
}