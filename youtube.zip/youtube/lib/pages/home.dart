import 'package:flutter/material.dart';
import 'package:youtube/pages/player.dart';
import 'package:youtube/services/api_client.dart';
import 'package:numeral/numeral.dart';
import 'package:timeago/timeago.dart' as timeago;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  ApiClient _apiClient = ApiClient();
  
  @override
  Widget build(BuildContext context) {
  return FutureBuilder( 
    future: _apiClient.getVideos(),
    builder: (BuildContext ctx,
  AsyncSnapshot<dynamic> snapshot){
    if(!snapshot.hasData){
      return const Center(child: CircularProgressIndicator());
    }
else if (snapshot.hasError){
  return const  Center(
    child: Text('Something went wrong'),
  );
} 
else {
  print('Data Comming..');
  return ListView.builder(
    itemCount: snapshot.data.length,
    itemBuilder: (c, int index ){
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          InkWell
          (onTap: (){
            Navigator.of(context).push(MaterialPageRoute(
              builder: (c)=>Player(snapshot.data[index]
              ['id'])
            ));

          },
            
            
            child: Image.network(snapshot.data[index]['snippet']['thumbnails']['high']['url'])),
    
          Row(children: [
         const  CircleAvatar(
            backgroundImage: NetworkImage('https://www.shareicon.net/data/512x512/2016/08/05/806962_user_512x512.png'),
          ),
          const SizedBox(width: 20,),
          Expanded(
            child: Text(snapshot.data[index]['snippet']['title'],
                // .toString()
                // .substring(0,20),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
            ),
          )],),
    Padding(
      padding: const EdgeInsets.only(left: 60),
      child: Row(children: [Text(Numeral(int.parse (snapshot.data[index]['statistics']['viewCount']))
      .format()),
     const  SizedBox(width: 20,),
      Text(timeago.format(
        DateTime.parse (snapshot.data[index]['snippet']['publishedAt'].toString())))
      
      ],
      ),
    )
        ],
      ),
    );
  });
}



  });
  }
}