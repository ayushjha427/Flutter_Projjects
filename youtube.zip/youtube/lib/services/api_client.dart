import 'package:dio/dio.dart';

class ApiClient{
  Dio _dio =  Dio ();
  Future<dynamic> getVideos() async {
const URL = 
        'https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&regionCode=IN&key=AIzaSyBQhvPoVhz9ot-NGqn1pk1kfGDhvighMs8';
 
 final Response response = await _dio.get(URL);
 //print(response.data);
 //print(response.data.runtimeType);
return response.data['items'];

  }
}